import "./nested";

register("chat", () => {
  ChatLib.chat("received!");
});
